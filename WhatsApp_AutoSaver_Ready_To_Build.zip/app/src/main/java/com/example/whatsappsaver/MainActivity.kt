package com.example.whatsappsaver

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnOpenSettings = findViewById<Button>(R.id.btnOpenSettings)
        val btnStartAutomation = findViewById<Button>(R.id.btnStartAutomation)

        btnOpenSettings.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
            Toast.makeText(this, "Enable 'WhatsApp Auto Saver' in Settings", Toast.LENGTH_LONG).show()
        }

        btnStartAutomation.setOnClickListener {
            // Check if accessibility service is enabled first
            // If yes, send a command to start the automation
            Toast.makeText(this, "Automation logic initialized. Please open WhatsApp Business.", Toast.LENGTH_LONG).show()
            
            // In a real implementation, we would use a BroadcastReceiver or similar
            // to notify the Service to start its scanning logic.
        }
    }
}
